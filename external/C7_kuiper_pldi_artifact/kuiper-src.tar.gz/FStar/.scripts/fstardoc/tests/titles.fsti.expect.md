## The `GHOST` effect
