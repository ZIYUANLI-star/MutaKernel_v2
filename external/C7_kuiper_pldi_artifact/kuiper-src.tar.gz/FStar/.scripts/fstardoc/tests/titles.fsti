(**** The [GHOST] effect *)
