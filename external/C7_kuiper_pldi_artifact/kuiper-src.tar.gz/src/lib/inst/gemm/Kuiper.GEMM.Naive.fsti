module Kuiper.GEMM.Naive

#lang-pulse
open Kuiper
open Kuiper.Poly.GEMMCPU
open Kuiper.Matrix.Reprs { row_major as RM, col_major as CM }

inline_for_extraction noextract
let size_req : size_req_t =
  fun rows shared cols -> rows * cols <= max_blocks

val matmul_f32_rrr : fixed_repr_matmul_cpu_ty f32 size_req RM RM RM
val matmul_f64_rrr : fixed_repr_matmul_cpu_ty f64 size_req RM RM RM
val matmul_u32_rrr : fixed_repr_matmul_cpu_ty u32 size_req RM RM RM
val matmul_u64_rrr : fixed_repr_matmul_cpu_ty u64 size_req RM RM RM

val matmul_f32_ccc : fixed_repr_matmul_cpu_ty f32 size_req CM CM CM
val matmul_f64_ccc : fixed_repr_matmul_cpu_ty f64 size_req CM CM CM
val matmul_u32_ccc : fixed_repr_matmul_cpu_ty u32 size_req CM CM CM
val matmul_u64_ccc : fixed_repr_matmul_cpu_ty u64 size_req CM CM CM

val g_matmul_f32_rrr : fixed_repr_mmcomb_gpu_ty f32 size_req RM RM RM
val g_matmul_f64_rrr : fixed_repr_mmcomb_gpu_ty f64 size_req RM RM RM
val g_matmul_u32_rrr : fixed_repr_mmcomb_gpu_ty u32 size_req RM RM RM
val g_matmul_u64_rrr : fixed_repr_mmcomb_gpu_ty u64 size_req RM RM RM

val g_matmul_f32_ccc : fixed_repr_mmcomb_gpu_ty f32 size_req CM CM CM
val g_matmul_f64_ccc : fixed_repr_mmcomb_gpu_ty f64 size_req CM CM CM
val g_matmul_u32_ccc : fixed_repr_mmcomb_gpu_ty u32 size_req CM CM CM
val g_matmul_u64_ccc : fixed_repr_mmcomb_gpu_ty u64 size_req CM CM CM
