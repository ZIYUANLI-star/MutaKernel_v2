module Kuiper.Poly.GEMM.Naive

(* This is a very naive matmul, spawning MxN blocks of 1 thread
to do the computation. *)

#lang-pulse

open Kuiper
open Kuiper.Poly.GEMMGPU.Type

inline_for_extraction noextract
val mmcomb_gpu_exact :
  matmulcomb_gpu_ty
    (fun rows shared cols -> rows * cols <= max_blocks)

inline_for_extraction noextract
val mmcomb_gpu_approx :
  matmulcomb_gpu_approx_ty
    (fun rows shared cols -> rows * cols <= max_blocks)

