module Kuiper.IntApprox
